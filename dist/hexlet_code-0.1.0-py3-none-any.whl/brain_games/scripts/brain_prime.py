from brain_games.games import engine
from brain_games.games import game_prime


def prime_or_not():

    engine.start_game(game_prime)


if __name__ == '__prime_or_not__':

    prime_or_not()
