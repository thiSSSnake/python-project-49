from brain_games.games import engine
from brain_games.games import game_progression

def game():
    engine.start_game(game_progression)


if __name__ == '__game__':

    game()
