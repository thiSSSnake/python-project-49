#!/usr/bin/env python3
from brain_games.games import engine
from brain_games.games import game_even

def game():
    engine.start_game(game_even)


if __name__ == '__game__':

    game()
