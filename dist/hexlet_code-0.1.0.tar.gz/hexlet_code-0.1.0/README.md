### Hexlet tests and linter status:
[![Actions Status](https://github.com/thiSSSnake/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/thiSSSnake/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/6c3b8084ea84f7da5cdf/maintainability)](https://codeclimate.com/github/thiSSSnake/python-project-49/maintainability)
https://asciinema.org/a/IoIHphpWbX1vzAnAMDwEYzoS9
https://asciinema.org/a/lv2GLx2O8JcYVr8j1B0bVaklF
https://asciinema.org/connect/1c31a81f-1dcb-4f31-b87d-08a295cf0493
